#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<mpi.h>

#include "image_utils.h"
#include "complex.h"
#include "julia_parallel_helpers.h"

#define MAX(a,b) (a)>(b)? (a): (b)
#define MIN(a,b) (a)<(b)? (a): (b)


////////////////////////////Helper methods start/////////////////////////
void recv_results(double* g, int numsamples, int* count,int* currentProcess, int staticallocation){
  MPI_Status status;
  int buffer[2];
  MPI_Recv(buffer,2,MPI_INT,MPI_ANY_SOURCE,1,MPI_COMM_WORLD,&status);
  int min = buffer[0];
  int max = buffer[1];
  MPI_Recv(g+min*numsamples,(max-min+1)*numsamples,MPI_DOUBLE,status.MPI_SOURCE,2,MPI_COMM_WORLD,&status);
  if (!staticallocation){
    *count = max-min+1;
    *currentProcess = status.MPI_SOURCE;
  }
}

void recv_rgb_results(double* r,double* g,double* b, int numsamples, int* count,int* currentProcess, int staticallocation){
  MPI_Status status;
  int buffer[2];
  MPI_Recv(buffer,2,MPI_INT,MPI_ANY_SOURCE,1,MPI_COMM_WORLD,&status);
  int min = buffer[0];
  int max = buffer[1];
  MPI_Recv(r+min*numsamples,(max-min+1)*numsamples,MPI_DOUBLE,status.MPI_SOURCE,4,MPI_COMM_WORLD,&status);
  MPI_Recv(g+min*numsamples,(max-min+1)*numsamples,MPI_DOUBLE,status.MPI_SOURCE,5,MPI_COMM_WORLD,&status);
  MPI_Recv(b+min*numsamples,(max-min+1)*numsamples,MPI_DOUBLE,status.MPI_SOURCE,6,MPI_COMM_WORLD,&status);
  if (!staticallocation){
    *count = max-min+1;
    *currentProcess = status.MPI_SOURCE;
  }
}

void send_results(double* results,int min, int max,int numsamples){
  int buffer[2]={min,max};
  MPI_Send(buffer,2,MPI_INT,0,1,MPI_COMM_WORLD);
  MPI_Send(results,(max-min+1)*numsamples,MPI_DOUBLE,0,2,MPI_COMM_WORLD);
}

void send_rgb_results(double* results_r,double* results_g, double* results_b,int min, int max,int numsamples){
  int buffer[2]={min,max};
  MPI_Send(buffer,2,MPI_INT,0,1,MPI_COMM_WORLD);
  MPI_Send(results_r,(max-min+1)*numsamples,MPI_DOUBLE,0,4,MPI_COMM_WORLD);
  MPI_Send(results_g,(max-min+1)*numsamples,MPI_DOUBLE,0,5,MPI_COMM_WORLD);
  MPI_Send(results_b,(max-min+1)*numsamples,MPI_DOUBLE,0,6,MPI_COMM_WORLD);
}

void send_quit(int p){
  int min = -1;
  int max = -1;
  int buffer[2]={min,max};
  MPI_Send(buffer,2,MPI_INT,p,3,MPI_COMM_WORLD);
}

void send_work(int p,int min, int max){
  int buffer[2]={min,max};
  MPI_Send(buffer,2,MPI_INT,p,3,MPI_COMM_WORLD);
}

void recv_work(int* min, int* max){
  MPI_Status status;
  int buffer[2];
  MPI_Recv(buffer,2,MPI_INT,0,MPI_ANY_TAG,MPI_COMM_WORLD,&status);
  *min=buffer[0];
  *max=buffer[1];
}

long int iterate(complex z,complex c,long int maxiter, double maxnorm){
  for(long int i=1; i<maxiter;i++){
    z=add(multiply(z,z),c);
    if(norm(z)>maxnorm){
      return i;
    }
  }
  return maxiter;
}


//HSV stuff for better color output.
typedef struct {
    double r;       // percent
    double g;       // percent
    double b;       // percent
} rgb;
typedef struct {
    double h;       // angle in degrees
    double s;       // percent
    double v;       // percent
} hsv;
static rgb   hsv2rgb(hsv in);


////////////////////////////Helper methods ends/////////////////////////

int main(int argc, char** argv){

  char* outputfile;
  int outputformat;
  double rmin;
  double rmax;
  double imin;
  double imax;
  long int maxiter;
  int numsamples;
  double maxnorm;

  complex c;

  int forcebyteswap;

  int rank;
  int numproc;
  int staticallocation;
  int linechunksize;
  MPI_Init(&argc,&argv);
  MPI_Comm_size(MPI_COMM_WORLD,&numproc);
  MPI_Comm_rank(MPI_COMM_WORLD,&rank);
  
  set_opts(argc,argv,&rmin, &rmax, &imin, &imax, &numsamples, &maxiter, &maxnorm, &outputfile, &outputformat,&c,&forcebyteswap,&staticallocation,&linechunksize);

  double deltar=(rmax-rmin)/numsamples;
  double deltai=(imax-imin)/numsamples;

  if (staticallocation){
    linechunksize=MIN(numsamples/(numproc-1)+1,numsamples);
   }

  
  
  if (rank==0){
    printf("Detected endianness is %s\n",is_little_endian()==1? "Little Endian":"Big Endian");
    double start=MPI_Wtime();
    printf("Processors: %d\nAllocation Method: %s\nline-chunk-size: %d\ndeltai:%f\ndeltar:%f\nmaxiter:%ld\nmaxnorm:%lf\noutput file: %s\nnumsamples:%d\nc:%f+%fi\n\n\n",numproc,staticallocation==0?"Dynamic":"Static",linechunksize,deltai,deltar,maxiter,maxnorm,outputfile,numsamples,c.real,c.imag); 
    int numworkers=numproc-1;
    if (numworkers<1){
      fprintf(stderr,"Wow I was never meant to be serial.\n");
      MPI_Abort(MPI_COMM_WORLD,1);
    }

    //Important stuff in here

////////////////////////////////Master Stuff Start/////////////////////////////////
        double* r;
        double* g;
        double* b;
        r=(double*)malloc(numsamples*numsamples*sizeof(double));
        g=(double*)malloc(numsamples*numsamples*sizeof(double));
        b=(double*)malloc(numsamples*numsamples*sizeof(double));
    
      if (staticallocation){
        //Static Allocation
        for (int i=0;i<numworkers;i++){
          if(outputformat==3){
            recv_rgb_results(r,g,b,numsamples,NULL,NULL,staticallocation);
          }else{
            recv_results(g,numsamples,NULL,NULL,staticallocation);
          }
        }
      }else {
        //Dynamic Allocation
        int max_assigned = 0;
        int top;
        for (int i=1;i<=numworkers;i++){
          top=MIN(linechunksize+max_assigned,numsamples);
          send_work(i,max_assigned,top-1);
          max_assigned+=top-max_assigned;
        }
        int datasource; 
        int count;
        int num_received = 0;
        while (num_received<numsamples){
          if(outputformat==3){
            recv_rgb_results(r,g,b,numsamples,&count,&datasource,staticallocation);
          }else{
            recv_results(g,numsamples,&count,&datasource,staticallocation);
          }
          num_received+=count;
          top=MIN(linechunksize+max_assigned,numsamples);
          if(max_assigned<numsamples){
            send_work(datasource,max_assigned,top-1);
            max_assigned+=top-max_assigned;
          }else{
            send_quit(datasource);
          }
        }
      }
////////////////////////////////Master Stuff Ends/////////////////////////////////

    if(outputformat==3){
        write_rgb_bmp(outputfile,r,g,b,numsamples,numsamples,0,maxiter,forcebyteswap);
        free(outputfile);
        free(g);free(r);free(b);
    }else{
        write_greyscale_bmp(outputfile,g,numsamples,numsamples,0,maxiter,forcebyteswap);
        free(outputfile);
        free(g);
    }
    
    

  }

  
  else{

    double start=MPI_Wtime();
    int quit=0;
    int number_of_lines_processed=0;
    //more important stuff in here. 

////////////////////////////////Worker Stuff Starts/////////////////////////////////
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
    int my_min;
    int my_max;
    complex z;
    int numworkers=numproc-1;
    if (staticallocation){
      //Staticallocation
      my_min=(rank-1)*linechunksize;
      if (rank==numworkers){
        my_max=numsamples-1;
      }else{
        my_max=rank*linechunksize-1;
      }
      double* my_results_r;
      double* my_results_g;
      double* my_results_b;
      
      my_results_g=malloc((my_max-my_min+1)*numsamples*sizeof(double));
      if(outputformat==3){
        my_results_r=malloc((my_max-my_min+1)*numsamples*sizeof(double));
        my_results_b=malloc((my_max-my_min+1)*numsamples*sizeof(double));
      }
      int calc_result;
      hsv hsv_result;
      rgb rgb_result;
      for (int i=0;i<numsamples;i++){
        for (int j=my_min;j<=my_max;j++){
          z.real = rmin + i * deltar;
          z.imag = imin + j * deltai;
          if(outputformat==3){
            //Main calculation
            calc_result=(int)iterate(z,c,maxiter,maxnorm);
            hsv_result.h=((double)i/(double)numsamples+(double)(numsamples-j)/(double)numsamples)*180.0;
            hsv_result.v=((double)calc_result/(double)maxiter);
            hsv_result.s=hsv_result.v;
            rgb_result=hsv2rgb(hsv_result);
            my_results_r[(j-my_min)*numsamples+i]=(double)maxiter*rgb_result.r;
            my_results_g[(j-my_min)*numsamples+i]=(double)maxiter*rgb_result.g;
            my_results_b[(j-my_min)*numsamples+i]=(double)maxiter*rgb_result.b;
          }else{
            my_results_g[(j-my_min)*numsamples+i] = (int)iterate(z,c,maxiter,maxnorm);
          }
        }  
      }
      number_of_lines_processed+=my_max-my_min+1;
      double end=MPI_Wtime();
      if(outputformat==3){
        send_rgb_results(my_results_r,my_results_g,my_results_b,my_min,my_max,numsamples);
      }else{
        send_results(my_results_g,my_min,my_max,numsamples);
      }
      free(my_results_g);
      if(outputformat==3){free(my_results_r);free(my_results_b);}
    }else{
      //Dynamic Arrangement
      double* my_results_r;
      double* my_results_g;
      double* my_results_b;
      while (1){
        recv_work(&my_min,&my_max);
        if(my_min==-1){break;};
        my_results_g=malloc((my_max-my_min+1)*numsamples*sizeof(double));
        if(outputformat==3){
          my_results_r=malloc((my_max-my_min+1)*numsamples*sizeof(double));
          my_results_b=malloc((my_max-my_min+1)*numsamples*sizeof(double));
        }
        int calc_result;
        hsv hsv_result;
        rgb rgb_result;
        for (int i=0;i<numsamples;i++){
          for (int j=my_min;j<=my_max;j++){
            z.real = rmin + i * deltar;
            z.imag = imin + j * deltai;
          if(outputformat==3){
            //Main calculation
            calc_result=(int)iterate(z,c,maxiter,maxnorm);
            hsv_result.h=((double)i/(double)numsamples+(double)(numsamples-j)/(double)numsamples)*180.0;
            hsv_result.v=((double)calc_result/(double)maxiter);
            hsv_result.s=hsv_result.v;
            rgb_result=hsv2rgb(hsv_result);
            my_results_r[(j-my_min)*numsamples+i]=(double)maxiter*rgb_result.r;
            my_results_g[(j-my_min)*numsamples+i]=(double)maxiter*rgb_result.g;
            my_results_b[(j-my_min)*numsamples+i]=(double)maxiter*rgb_result.b;
          }else{
            my_results_g[(j-my_min)*numsamples+i] = iterate(z,c,maxiter,maxnorm);
          }
          }  
	}
        if(outputformat==3){
          send_rgb_results(my_results_r,my_results_g,my_results_b,my_min,my_max,numsamples);
        }else{
	  send_results(my_results_g,my_min,my_max,numsamples);
        }
	number_of_lines_processed+=my_max-my_min+1;
	free(my_results_g);
        if(outputformat==3){free(my_results_r);free(my_results_b);}
      }
    }

////////////////////////////////Worker Stuff Ends/////////////////////////////////

    double end=MPI_Wtime();
    
    printf("Rank %d processed %d line in %lf seconds to complete.\n",rank,number_of_lines_processed,end-start);
  }

  
  
  MPI_Finalize();
  return 0;
}




//HSV2RGB conversion from Internet
//For better color output
rgb hsv2rgb(hsv in)
{
    double      hh, p, q, t, ff;
    long        i;
    rgb         out;

    if(in.s <= 0.0) {       // < is bogus, just shuts up warnings
        out.r = in.v;
        out.g = in.v;
        out.b = in.v;
        return out;
    }
    hh = in.h;
    if(hh >= 360.0) hh = 0.0;
    hh /= 60.0;
    i = (long)hh;
    ff = hh - i;
    p = in.v * (1.0 - in.s);
    q = in.v * (1.0 - (in.s * ff));
    t = in.v * (1.0 - (in.s * (1.0 - ff)));

    switch(i) {
    case 0:
        out.r = in.v;
        out.g = t;
        out.b = p;
        break;
    case 1:
        out.r = q;
        out.g = in.v;
        out.b = p;
        break;
    case 2:
        out.r = p;
        out.g = in.v;
        out.b = t;
        break;

    case 3:
        out.r = p;
        out.g = q;
        out.b = in.v;
        break;
    case 4:
        out.r = t;
        out.g = p;
        out.b = in.v;
        break;
    case 5:
    default:
        out.r = in.v;
        out.g = p;
        out.b = q;
        break;
    }
    return out;     
}
