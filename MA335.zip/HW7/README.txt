The program works fine. 
RGB implementation is added, using HSV conversion which looks redundant but outputs nice looking plot. 
--outputformat=rgb will enable RGB output. --maxiterations=256 can give nice plot.