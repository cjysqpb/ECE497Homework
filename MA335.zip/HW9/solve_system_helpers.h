#ifndef SOLVE_SYSTEM_HELPERS
#define SOLVE_SYSTEM_HELPERS

#include<stdio.h>
#include<stdlib.h>
#include<time.h>



//Defines a matrix struct.  The matrix has m rows and n columns.
typedef struct matrix{
  int m;        //Number of rows in the matrix
  int n;        //Number of columns in the matrix

  double* data; //This is a pointer to the array data.  This stores the data as a linear array, so
                //accesible as data[k].  The data is stored in row-major order, so the array is laid out as
                //a_11 a_12 a_13 ...  a_1N a_21 a_22 a_23 ... a_2N ... a_NN. 

  double** entry; //points the the data of the matrix, but represents a 2-D array.  So, entry[i][j] gives the entry of the matrix
                  //in row i, column j.  Incidentally, entry[i] is the address of entry[i][0].
                  //Also, keep in mind that everything here is 0-indexed. 
  
}matrix;


//Correctly set upt the entry array in a matrix if its m,n,and data entries are already set up.
//Not hard.  Just tedious. 
void setup_entry_array(matrix* A){
  A->entry=malloc(sizeof(double*) * A->m);
  int i;
  for (i=0;i<A->m;i++){
    A->entry[i]=A->data+i*A->n;
  }
}

//Read a matrix out of a plain text file.
//text file must contain the dimenstions of the matrix in the first line,
//and then the matrix data thereafter. 

matrix read_matrix(char* filename){

  FILE* fp=fopen(filename,"r");

  if (fp==NULL){
    fprintf(stderr,"Error opening %s for reading. \n",filename);
    exit(1);
  }
  matrix A;

  if (fscanf(fp,"%d,%d",&(A.m),&(A.n))!=2){
    fprintf(stderr,"Error reading line 1 of %s.\n",filename);
    exit(1);
  }

  int i;
  int j;
  A.data=malloc(sizeof(double)*A.m*A.n);
  for (i=0;i<A.m;i++){
    if (fscanf(fp,"%lf",A.data+A.n*i)!=1){
      fprintf(stderr,"Error reading %s.\n",filename);
      exit(1);
    }
    for (j=1;j<A.n;j++){
      if (fscanf(fp,",%lf",A.data+A.n*i+j)!=1){
	fprintf(stderr,"Error reading %s.\n",filename);
	exit(1);
      }
    }
  }

  setup_entry_array(&A);
  
  fclose(fp);
  return A;


}


//Initialize a new matrix of size m x n.  The data is will be allocated for you, and the entry array all set up.
//But, the data in there is pure garbage. 
matrix new_matrix(int m, int n){

  matrix A;
  A.m=m;
  A.n=n;
  A.data=malloc(m*n*sizeof(double));

  setup_entry_array(&A);
  
  return A;
}

//Free a matrix after it is allocated.
void free_matrix(matrix A){
  free(A.data);
  free(A.entry);
}

//Print a matrix to file.  
void fprintmatrix(FILE* fp,matrix A,char delim){

  int i;
  int j;
  for (i=0;i<A.m;i++){
    for (j=0;j<A.n;j++){
      fprintf(fp,"%lf",A.data[i*A.n+j]);
      if (j<A.n-1){
	fprintf(fp,"%c",delim);
      }
    }
    fprintf(fp,"\n");
  }
    
}


//Write the matrix A to the filename.
void write_matrix(char* filename, matrix A){

  FILE* fp=fopen(filename,"w");
  if (fp==NULL){
    fprintf(stderr,"Error opening %s for writing.\n",filename);
    exit(1);
  }

  fprintf(fp,"%d,%d\n",A.m,A.n);
  fprintmatrix(fp,A,',');
  
  fclose(fp); 


}

//Print a matrix to the command prompt. 
void printmatrix(matrix A){
  fprintmatrix(stdout,A,' ');
}

//Create a random matrix of size m x n with entries between min and max. 
matrix random_matrix(int m,int n,int min, int max){

  matrix A=new_matrix(m,n);
  int i;
  int j;

  srand(time(NULL));
  for (i=0;i<m;i++){
    for (j=0;j<n;j++){
      A.data[i*n+j]=rand()%(max-min)+min;
    }
  }

  
  return A;
  
}

#endif


  
