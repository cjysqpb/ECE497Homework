#include <stdio.h>
#include <stdlib.h>
#include "solve_system_helpers.h"

#include <mpi.h>


void main(int argc,char** argv){
	
	int rank, numproc;
	MPI_Init(&argc,&argv);
	MPI_Comm_size(MPI_COMM_WORLD,&numproc);
	MPI_Comm_rank(MPI_COMM_WORLD,&rank);
	MPI_Status status;
	
	if(rank==0){
		if (argc<3){
			printf("Usage: solve_system A b x\n");
			printf("Here A is the file storing the matrix A\n");
			printf("b is the file storing the vector b");
			printf("and x is the output file");
			exit(1);
		}
	}

	matrix A=read_matrix(argv[1]);
	matrix b=read_matrix(argv[2]);
	matrix x=new_matrix(b.m,1);

	//printmatrix(A);
	printf("A[3][2]=%lf\n",A.entry[3][2]);
	// do some stuff.
	
	// It will iter more than one time if more processor than row number.
	// Using striped partition
	int num_iter=A.m/numproc;
	if (rank < A.m%numproc){
		num_iter++;
	}
	
	// Last processor stores the final row reduction result.
	int last_proc=A.m%numproc-1;
	if(last_proc<0){
		last_proc=numproc-1;
	}
	

	// First section: loop through, reduce head of row to zero.
	// Result:
	// 		x x x x
	//		0 x x x
	//		0 0 x x
	//		0 0 0 x
	for(int i=0;i<num_iter;i++){
		
		// The row that this processor takes responsbility of.
		int m_start=i*numproc+rank;
		
		// Doing exactly samething that shown on the last solver class.
		for(int n_start=0;n_start<=m_start;n_start++){
		
			//Fetch Data form previous proc (not run on last cycle or proessor 0 with first row)
			if(n_start!=m_start){
				if(rank==0&&m_start>0){
					MPI_Recv(A.entry[n_start],A.n,MPI_DOUBLE,numproc-1,0,MPI_COMM_WORLD,&status);
					MPI_Recv(b.entry[n_start],1,MPI_DOUBLE,numproc-1,1,MPI_COMM_WORLD,&status);
				}else if(rank!=0){
					MPI_Recv(A.entry[n_start],A.n,MPI_DOUBLE,rank-1,0,MPI_COMM_WORLD,&status);
					MPI_Recv(b.entry[n_start],1,MPI_DOUBLE,rank-1,1,MPI_COMM_WORLD,&status);
				}
			}
			
			//Send data to next processor
			if(m_start<A.m-1){
				if(rank==numproc-1){
					MPI_Send(A.entry[n_start],A.n,MPI_DOUBLE,0,0,MPI_COMM_WORLD);
					MPI_Send(b.entry[n_start],1,MPI_DOUBLE,0,1,MPI_COMM_WORLD);
				}else{
					MPI_Send(A.entry[n_start], A.n,MPI_DOUBLE,rank+1,0,MPI_COMM_WORLD);
					MPI_Send(b.entry[n_start],1,MPI_DOUBLE,rank+1,1,MPI_COMM_WORLD);
				}
			}
			
			//Row reduce (not run on last cycle)
			if(n_start!=m_start){
				double ratio = A.entry[n_start][n_start] / A.entry[m_start][n_start];
				for (int n_index=n_start;n_index<A.n;n_index++){
					A.entry[m_start][n_index] = A.entry[m_start][n_index]*ratio - A.entry[n_start][n_index];
				}
				b.entry[m_start][0] = b.entry[m_start][0]*ratio - b.entry[n_start][0];
			}
		
		}
		
	}
	
	
	//if(rank==last_proc){printf("Last Processor is %d says:\n",rank);printmatrix(A);printmatrix(b);}
	
	// Second section: loop reversely, reduce rest of row to zero.
	// Result:
	// 		1 0 0 0 b1
	//		0 1 0 0 b2
	//		0 0 1 0 b3
	//		0 0 0 1 b4
	for(int i=num_iter-1;i>=0;i--){
		
		// The row that this processor takes responsbility of.
		int m_start=i*numproc+rank;
		
		// Receive Data from next row (shorter row)
		if(m_start<A.m-1){
			if(rank==numproc-1){
				MPI_Recv(x.entry[m_start+1],x.m-(m_start+1),MPI_DOUBLE,0,1,MPI_COMM_WORLD,&status);
			}else{
				MPI_Recv(x.entry[m_start+1],x.m-(m_start+1),MPI_DOUBLE,rank+1,1,MPI_COMM_WORLD,&status);
			}
		}
		
		// Find solution and record to b
		for(int n=A.m-1;n>m_start;n--){
			b.entry[m_start][0] = b.entry[m_start][0] - x.entry[n][0] * A.entry[m_start][n];
		}
		
		// Scale to make row head to 1.
		x.entry[m_start][0]=b.entry[m_start][0]/A.entry[m_start][m_start];
		
		// Send solved row
		if (rank==0&&m_start>0){
			MPI_Send(x.entry[m_start],x.m-m_start,MPI_DOUBLE,numproc-1,1,MPI_COMM_WORLD);
		}else if(rank!=0){
			MPI_Send(x.entry[m_start],x.m-m_start,MPI_DOUBLE,rank-1,1,MPI_COMM_WORLD);
		}
	}
	
	
	if(rank==0){
		write_matrix(argv[3],x);
	}
	
	MPI_Finalize();
}
