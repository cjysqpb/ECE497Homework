My code seems working perefectly. 
It is implemented using the algorithm on last solver class (striped partitioning) to reduce rows.
(Processor 0 will be the next worker after last processor.)
