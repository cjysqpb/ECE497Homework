#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#include "image_utils.h"
#include "complex.h"
#include "julia_helpers.h"


long int iterate(complex z,complex c,long int maxiter, double maxnorm){
  for(long int i=1; i<maxiter;i++){
    z=add(multiply(z,z),c);
    if(norm(z)>maxnorm){
      return i;
    }
  }
  return maxiter;
}



int main(int argc, char** argv){

  char* outputfile;
  int outputformat;
  double rmin;
  double rmax;
  double imin;
  double imax;
  long int maxiter;
  int numsamples;
  double maxnorm;

  complex c;

  int forcebyteswap;
  set_opts(argc,argv,&rmin, &rmax, &imin, &imax, &numsamples, &maxiter, &maxnorm, &outputfile, &outputformat,&c,&forcebyteswap);
  
  double* r,*g,*b;
  short int* m;
  
  //Allocate Space
  switch(outputformat){
  case 0:
    g=malloc((numsamples*numsamples)*sizeof(double));
    break;
  case 1:
    m=malloc((numsamples*numsamples)*sizeof(long int));
    break;
  case 2:
    g=malloc((numsamples*numsamples)*sizeof(double));
    break;
  case 3:
    r=malloc((numsamples*numsamples)*sizeof(double));
    g=malloc((numsamples*numsamples)*sizeof(double));
    b=malloc((numsamples*numsamples)*sizeof(double));
    break;
  }
  
  int i,j;
  double deltar=(rmax-rmin)/(numsamples-1);
  double deltai=(imax-imin)/(numsamples-1);

  printf("deltai:%f\ndeltar:%f\nmaxiter:%ld\nmaxnorm:%lf\noutput file: %s\nc:%f+%fi\n",deltai,deltar,maxiter,maxnorm,outputfile,c.real,c.imag);

  complex z;
  z.real=0;
  z.imag=0;
  long int cal_result;
  hsv hsv_result;
  rgb rgb_result;
  // stuff here to set up theg, m, r arrays as needed. 
  for (long int i=0;i<numsamples;i++){
    for(long int j=0;j<numsamples;j++){
      z.real=rmin+i*deltar;
      z.imag=imin+j*deltar;
      //ROW_MAJOR array. i row, j column.
      switch(outputformat){
        case 0:
          g[j*numsamples+i]=iterate(z,c,maxiter,maxnorm);
          break;
        case 1:
          if(iterate(z,c,maxiter,maxnorm)==maxiter){m[j*numsamples+i]=1;}
          else{m[j*numsamples+i]=0;}
          break;
        case 2:
          g[j*numsamples+i]=iterate(z,c,maxiter,maxnorm);
          break;
        case 3:
		  用珏哥写法
          break;
      }
    }
  }


  switch (outputformat){
  case 0:
    write_ppm(outputfile,g,numsamples,numsamples,0,maxiter);
    break;
  case 1: 
    write_monochrome_bmp(outputfile,m,numsamples,numsamples,forcebyteswap);
    break;
  case 2:
    write_greyscale_bmp(outputfile,g,numsamples,numsamples,0,maxiter,forcebyteswap);
    break;
  case 3:
    write_rgb_bmp(outputfile,r,g,b,numsamples,numsamples,0,maxiter,forcebyteswap);
  }

  free(outputfile);

  switch (outputformat){
  case 0:
    free(g);
    break;
  case 1:
    free(m);
    break;
  case 2:
    free(g);
    break;
  case 3:
    free(g);free(r);free(b);
    break;
  }
  
  
  return 0;
}

