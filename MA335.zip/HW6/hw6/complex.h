//Complex header handling complex value.
typedef struct complex{
  double real;
  double imag;
}complex;

complex add(complex x, complex y){
  x.real=x.real+y.real;
  x.imag=x.imag+y.imag;
  return x;
}

complex subtract(complex x, complex y){
  x.real=x.real-y.real;
  x.imag=x.imag-y.imag;
  return x;
}


complex multiply(complex x, complex y){
  complex result;
  result.real=(x.real*y.real)-(x.imag*y.imag);
  result.imag=(x.real*y.imag)+(x.imag*y.real);
  return result;
}


double norm(complex x){
  double result=(x.real*x.real+x.imag*x.imag);
  return result;
}
