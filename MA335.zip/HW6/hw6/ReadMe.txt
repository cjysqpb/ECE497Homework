My code seems working well.
I use HSV to color the color output, and then convert it into RGB to feed the util.
