#include<stdio.h>
#include<stdlib.h>
#include<mpi.h>
#include<math.h>
#include<string.h>


//return 2^p
int pow2(int p){
  int i;
  int twop;
  twop=1;
  for (i=0;i<p;i++){
    twop*=2;
  }
  return twop;
}


//Helper function My_accumulator is a modified my_gather algorithm implemented during the class.
void my_accumulator(int* recvbuf, int* sendbuf, int root, MPI_Comm COMM){

  int numproc, rank;
  MPI_Comm_size(COMM,&numproc);
  MPI_Comm_rank(COMM,&rank);
  MPI_Status status;

  int n_steps=log2(numproc);

  int i;
  int active;
  int amsending;
  int amrecving;
  
  int sendingto;
  int recvingfrom;
 
  //Copy the initial data to accubuffer to accumulate.
  int* accubuffer=malloc(sizeof(int));
  memcpy(accubuffer,sendbuf,sizeof(int));

  for (i=1;i<=n_steps;i++){
    //Tree algorithm.
    if (rank % pow2(i-1) == 0){
      active=1;
    }
    else{
      active=0;
    }
    if (active){
      if (rank % pow2(i) ==0  ){
	//Recieving	
	amrecving=1;
	amsending=0;
	recvingfrom=rank+pow2(i-1);

	//Accumulate the data
	int temp=*accubuffer;
	MPI_Recv(accubuffer,1,MPI_INT,recvingfrom,0,COMM,&status);
	*accubuffer=temp+*accubuffer;
      }else{
	//Sending. 
	amsending=1;
	amrecving=0;
	sendingto=rank-pow2(i-1);

	MPI_Send(accubuffer,1,MPI_INT,sendingto,0,COMM);
	free(accubuffer);
      }
      
    }

  }

  //Copy its data back to recvbuffer.
  if (rank==0){
    memcpy(recvbuf,accubuffer,sizeof(int));
    //The root never sends, so its accubuffer has never been free'd. Do that.
    free(accubuffer);
  }
}

//The main function "my_allplus"
void my_allplus(int *sendbuf, int *recvbuf, int count, MPI_Datatype datatype, MPI_Comm comm){
    
	int rank;
    int numproc;
    MPI_Comm_size(MPI_COMM_WORLD,&numproc);
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
	int local_sum=0;
	//each processor sums its own data.	
	for(int i=0;i<count;i++){
		local_sum+=sendbuf[i];
	}
	if((int)(numproc&(numproc-1))==0){
		//Power of 2, use binary algorithm.
		if(rank==0){printf("Note: Is power of 2, calculation fast in O(logN)----\n");};
		my_accumulator(recvbuf, &local_sum, 0, comm);
	}else{
		//Not power of 2, use traditional method. 
		if(rank==0){
			//Rank 0 sums all together.
			printf("Note: Not power of 2, calculation slow in O(N)----\n");
			int tmprecvbuf[numproc]; 
			MPI_Gather(&local_sum,1,datatype,tmprecvbuf,1,datatype,0,MPI_COMM_WORLD);
			int local_total=0;
			for(int i=0;i<numproc;i++){
				local_total+=tmprecvbuf[i];
			}
			recvbuf[0]=local_total;
		}else{
			MPI_Gather(&local_sum,1,datatype,NULL,0,datatype,0,MPI_COMM_WORLD);
		}
	}
	MPI_Bcast(recvbuf,1,datatype,0,MPI_COMM_WORLD);	
	
}

void main(int argc, char** argv){

  MPI_Init(&argc,&argv);
  int rank;
  int numproc;
  MPI_Comm_size(MPI_COMM_WORLD,&numproc);
  MPI_Comm_rank(MPI_COMM_WORLD,&rank);

  int local_data_size=3;
  int sendbuf[local_data_size];
  int recvbuf[1];
  int i;

  printf("Rank %d has local data: ",rank);
  for (i=0;i<local_data_size;i++){
    sendbuf[i]=rank*rank+i; 
	printf(" %d",sendbuf[i]);   
  }
  printf("\n");

  int gather_dest=0;
  
  my_allplus(sendbuf, recvbuf, local_data_size, MPI_INT, MPI_COMM_WORLD);
  printf("After allplus, Rank %d has recvbuf[0] data: %d\n",rank, recvbuf[0]);
  MPI_Finalize();


}
