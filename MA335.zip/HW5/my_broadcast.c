#include<mpi.h>
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>

//return 2^p
int pow2(int p){
  int i;
  int twop;
  twop=1;
  for (i=0;i<p;i++){
    twop*=2;
  }
  return twop;
}

//Main function
void my_broadcast(int *buffer, int count, MPI_Datatype datatype, int root, MPI_Comm COMM){

  int numproc, rank;
  MPI_Comm_size(COMM,&numproc);
  MPI_Comm_rank(COMM,&rank);
  MPI_Status status;

  if((int)(numproc&(numproc-1))!=0){
  //If not power of 2, using tradition method.
	if(rank==root){
		printf("Not power of 2, running in O(N) low speed\n");
		for (int i=1;i<numproc;i++){
			if(rank!=i){MPI_Send(buffer,count,datatype,i,0,COMM);}
		}
    }else{
		MPI_Recv(buffer,count,datatype,root,0,COMM,&status);
	}
	return;
  }
  //Power of 2 so using binary tree algorithm.
  if(rank==root){printf("Power of 2, running in O(log N) high speed\n");}
  int n_steps=log2(numproc);

  int i;
  int active;
  int sendingto;
  int recvingfrom;

  for (i=n_steps;i>=1;i--){//from large to small reserve loop
    //Tree algorithm.
    if (rank % pow2(i-1) == 0){
      active=1;
    }
    else{
      active=0;
    }
    if (active){
      if (rank % pow2(i) ==0  ){
	//Sending	
	sendingto=rank+pow2(i-1);

	MPI_Send(buffer,count,datatype,sendingto,0,COMM);
	
      }else{
	//Receiving. 
	recvingfrom=rank-pow2(i-1);

	MPI_Recv(buffer,count,datatype,recvingfrom,0,COMM,&status);

      }
      
    }

  }
}

int main(int argc, char** argv){
  MPI_Init(&argc,&argv);
  int total_procs;
  int rank;
  MPI_Comm_size(MPI_COMM_WORLD,&total_procs);
  MPI_Comm_rank(MPI_COMM_WORLD,&rank);
  int i;
 if (rank==0){
   int data[10]={1,1,2,3,5,8,13,21,34,55};
	printf("Rank0 initially has data:");
	for (i=0;i<10;i++){
      		printf("%d ",data[i]);
    	}
	printf("\n");
	my_broadcast(data, 10, MPI_INT, 0, MPI_COMM_WORLD);
  }
  else{
    int recvd_data[10];
	my_broadcast(recvd_data, 10, MPI_INT, 0, MPI_COMM_WORLD);
    int i;
    printf("Rank: %d Data:",rank);
    for (i=0;i<10;i++){
      printf("%d ",recvd_data[i]);
    }
    printf("\n");
  } 


  MPI_Finalize();

}
