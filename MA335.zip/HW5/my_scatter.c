#include<mpi.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

//Helper funtion to do data copy.
void copy_buffer(int* dest, const int* src, int n){
  memcpy(dest,src,n*sizeof(int));
}

//Main method
void my_scatter(int *sendbuf, int sendcount, MPI_Datatype sendtype, void *recvbuf, int recvcount, MPI_Datatype recvtype, int root, MPI_Comm comm){
	
	int numproc, rank;
	MPI_Comm_size(comm,&numproc);
	MPI_Comm_rank(comm,&rank);
	MPI_Status status;

	if(rank==root){
		int offset=0;
		for(int i=0;i<numproc;i++){
			if(i==root){
				copy_buffer(recvbuf,sendbuf+offset*sendcount,sendcount);
			}else{
				MPI_Send(sendbuf+offset*sendcount,sendcount,sendtype,i,0,comm);		
			}
			offset+=1;
		}
	}else{
		MPI_Recv(recvbuf,recvcount,recvtype,root,0,comm,&status);
	}

}


int main(int argc, char** argv){
  MPI_Init(&argc,&argv);
  int total_procs;
  int rank;
  MPI_Comm_size(MPI_COMM_WORLD,&total_procs);
  MPI_Comm_rank(MPI_COMM_WORLD,&rank);
  int i;
  int root=1;
  int send_length=3;
  int data_size=10;
  int recvbuf[send_length];

 if (rank==root){
    //Generate Data
    int data[10]={1,2,3,4,5,6,7,8,9,10};
    printf("Rank %d initially has %d data sets: ",rank,data_size);
	
    int i;
    for (i=0;i<data_size;i++){
      printf("%d ",data[i]);
    }
    printf("\n");
	printf("Rank %d will scatter data to others with 3 sets per processor.\n",rank);
	if(total_procs*send_length>data_size){
		printf("Unable to scatter 10 data to %d processors with %d data per processor\n",total_procs,send_length);
		printf("Some error may occur\n");
	}
	my_scatter(data,send_length,MPI_INT, recvbuf,send_length,MPI_INT,root,MPI_COMM_WORLD);
  }
  else{
    
	my_scatter(NULL,send_length,MPI_INT,recvbuf,send_length,MPI_INT,root,MPI_COMM_WORLD);
  } 

  printf("After scatter: Rank: %d Data:",rank);
  for (i=0;i<send_length;i++){
	printf(" %d",recvbuf[i]);
  }
  printf("\n");
  MPI_Finalize();

}
