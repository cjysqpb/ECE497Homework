#include<stdio.h>
#include<stdlib.h>
#include<mpi.h>
#include<math.h>
#include<string.h>


//return 2^p
int pow2(int p){
  int i;
  int twop;
  twop=1;
  for (i=0;i<p;i++){
    twop*=2;
  }
  return twop;
}

//print a buffer of length n. 
void printbuffer(int* buffer, int n){

  int i;
  printf("[");
  for (i=0;i<n;i++){
    printf("%d ", buffer[i]);
  }
  printf("]\n");

  
}


//copy data in src to dest.  src is n integers long.
//dest must be allocated already. 
void copy_buffer(int* dest, int* src, int n){
  memcpy(dest,src,n*sizeof(int));
}


//Takes as input an inputbuffer that is n integers long.
//Allocates a new buffer, outputbuffer, that is 2n integers long and that contains
//inputbuffer in the first n positions. 
int* doublebuffer(int* inputbuffer,int n){
  int* outputbuffer=malloc(2*n*sizeof(int));
  int i;
  for(i=0;i<n;i++){
    outputbuffer[i]=inputbuffer[i];
  }
  return outputbuffer;
}


//Reproduces some functionality of MPI_Gather. 
void my_gather(int* recvbuf, int recvcount, int* sendbuf, int sendcount, int root, MPI_Comm COMM){

  int numproc, rank;
  MPI_Comm_size(COMM,&numproc);
  MPI_Comm_rank(COMM,&rank);

  int n_steps=log2(numproc);

  int i;
  // indicates whether or not this process does anything on this "step" of the gather.
  int active;
  // if the process is active, is it a sender, or a reciever?
  int amsending;
  int amrecving;
  
  // If I'm sending, to whom am I sending?
  int sendingto;
  // If I'm recieving, from whom am I recveiving?
  int recvingfrom;

  //Status variable for recieves. Mostly ignored. 
  MPI_Status status;


  //The data that I hold that I want to pass on to the root.
  //initially is my local data, in sendbuf.  Grows as I recieve data from buddies to pass on. 
  int* outgoingbuffer=malloc(sendcount*sizeof(int));
  copy_buffer(outgoingbuffer, sendbuf, sendcount);
  //Since outgoing buffer grows over time, let's just keep track of how big it is.  Yes I could write an
  //an expression for this.  Yes I would probably mess it up.
  int outgoingbufferlen=sendcount;
  

  

  for (i=1;i<=n_steps;i++){
    //Do I do anything during this step of the algorithm?
    if (rank % pow2(i-1) == 0){
      active=1;
    }
    else{
      active=0;
    }
    if (active){
      //I'm active.  Am I sending or am I recieving?
      if (rank % pow2(i) ==0  ){
	amrecving=1;
	amsending=0;
	//I'm recieving.  That means that I need to append the data I get to my outputbuffer.

	//double my current outputbuffer,
	int* tmpoutgoingbuffer=doublebuffer(outgoingbuffer,outgoingbufferlen);
	//free up the old outputbuffer
	free(outgoingbuffer);
	outgoingbuffer=tmpoutgoingbuffer;
	outgoingbufferlen=outgoingbufferlen*2;

	//Look at picture to see that I need to recieve from this process.
	recvingfrom=rank+pow2(i-1);

	
	printf("Step %d Rank %d is recving from rank %d\n",i,rank,recvingfrom);

	//To append, just put the new data that I get half way through the new outputbuffer. 
	MPI_Recv(outgoingbuffer+outgoingbufferlen/2,outgoingbufferlen/2,MPI_INT,recvingfrom,0,COMM,&status);
	//Check to see that I'm making sense.
	printf("Step %d and rank %d now has outputbuffer: ",i, rank);
	printbuffer(outgoingbuffer,outgoingbufferlen);
	
      }
      
      else{
	//I'm sending.  Take my outgoing buffer and send it to my appropriate partner. 
	amsending=1;
	amrecving=0;
	//Just look at the picture to see who I send to at this step of the algorithm. 
	sendingto=rank-pow2(i-1);
	printf("Step %d Rank %d is sending to %d\n",i,rank,sendingto);
	//Now the send is easy because I've been keeping track of everying. 
	MPI_Send(outgoingbuffer,outgoingbufferlen,MPI_INT,sendingto,0,COMM);
	//We can free up my outgoing buffer. I don't need it anymore.
	free(outgoingbuffer);
      }
      
    }

  }

  //Last step is for the root to copy its data back to recvbuffer.
  if (rank==0){
    copy_buffer(recvbuf,outgoingbuffer,outgoingbufferlen);
    //The root never sends, so its outgoingbuffer has never been free'd. Do that.
    free(outgoingbuffer);

  }

  


}


void main(int argc, char** argv){
  MPI_Init(&argc,&argv);
  int rank;
  int numproc;
  MPI_Comm_size(MPI_COMM_WORLD,&numproc);
  MPI_Comm_rank(MPI_COMM_WORLD,&rank);

  int local_data_size=2;
  int local_data[local_data_size];
  int i;

  for (i=0;i<local_data_size;i++){
    local_data[i]=rank*rank+i;    
  }
  
  //for (i=0;i<local_data_size;i++){
  //  printf("Rank %d data entry %d is %d\n",rank,i,local_data[i]);
  //}


  int gather_dest=0;
  
  if (rank==gather_dest){
    int* recvbuf = malloc(local_data_size*numproc*sizeof(int));
    my_gather(recvbuf, local_data_size, local_data, local_data_size, gather_dest, MPI_COMM_WORLD);
    printf("After my_gather, root has data: \n");
    for (i=0;i<local_data_size*numproc;i++){
      printf("%d ",recvbuf[i]);
    }
    printf("\n");
    free(recvbuf);
  }
  
  else{
    my_gather(NULL, 0, local_data, local_data_size, gather_dest, MPI_COMM_WORLD);
  }

  
  MPI_Finalize();


}
