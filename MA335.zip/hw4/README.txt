Some problems:

For problem comm_speed, I did not find a way to transmit a chunk in a single operation, when the chunk is larger than 9MB. So I divided the chunk into several small pieces and send by multiple times, which may cause a little bit inaccurate measurement. 

For problem estimate_pi, I used math.h header. It seems that we need -lm after the mpicc command to make it work. 
e.g.: mpicc -o estimate_pi estimate_pi.c -lm

