#include<stdio.h>
#include<stdlib.h>
#include<mpi.h>

int main(int argc, char** argv){
  MPI_Init(&argc,&argv);
  int total_procs;
  int rank;
  MPI_Comm_size(MPI_COMM_WORLD,&total_procs);
  MPI_Comm_rank(MPI_COMM_WORLD,&rank);
  if (rank==0){
    
    printf("Welcome to the message broadcaster.  Enter an integer to broadcast to all worker nodes.  Enter -1 to quit. \n");
    while(1){
    
    fflush(stdout);
    char input;
    scanf("%d",&input);
    int i;
    char* message=&input;
    MPI_Status status;
    for (i=1;i<total_procs;i++){
      MPI_Send(message,18,MPI_CHAR,i,0,MPI_COMM_WORLD);
    }
    if(input==-1){break;}
    }
  }
  else{
    while(1){
    MPI_Status status;
    char recv_buffer[1];
    MPI_Recv(recv_buffer,20,MPI_CHAR,MPI_ANY_SOURCE,MPI_ANY_TAG,MPI_COMM_WORLD,&status);
    printf("Process Ranked %d: Number received from rank %d:%d\n",rank,status.MPI_SOURCE,*recv_buffer);
    if(*recv_buffer==-1){break;}
    }
  }
  MPI_Finalize();
}
