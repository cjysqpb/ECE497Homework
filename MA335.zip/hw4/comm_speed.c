#include<stdio.h>
#include<stdlib.h>
#include<mpi.h>
#include<unistd.h>

int main(int argc, char** argv){
  int B = atoi(argv[1]);
  int E = atoi(argv[2]);
  MPI_Init(&argc,&argv);
  int total_procs;
  int rank;
  MPI_Comm_size(MPI_COMM_WORLD,&total_procs);
  MPI_Comm_rank(MPI_COMM_WORLD,&rank);
  char name[1000];
  gethostname(name,1000);
  long long chunk_size=B*1024;
  double chunk[chunk_size];
  double chunk_recv[chunk_size];
  for(long long i=0;i<chunk_size;i++){
	chunk[i]=i;
  }
  if(total_procs%2==1){
	if(rank==0){printf("Please input even number of process. Exiting..\n");}
  }else if (rank==0){
	printf("Communication Speed Test\n");
	printf("----------\n");
	printf("Data Size: %dMB\n",B);
	printf("Number of Experiences: %d\n",E);
	printf("Rank %d on %s\n",rank, name);
	double starttime, endtime;
	MPI_Status status;
	double dtime=0;
	for (int e=0;e<E;e++){
	starttime=MPI_Wtime();
	for (int i=0;i<128;i++){
		MPI_Send(&chunk,chunk_size,MPI_DOUBLE,rank+1,0,MPI_COMM_WORLD);
		MPI_Recv(chunk_recv,chunk_size,MPI_DOUBLE,MPI_ANY_SOURCE,MPI_ANY_TAG,MPI_COMM_WORLD,&status);	
	}
	endtime=MPI_Wtime();
	dtime+=endtime-starttime;
	}	
	double speed=B/(dtime/(2*E));
	printf("%d <--> %d Transmission Rate: %f MB/s\n",rank, rank+1,speed);
  }
  else if (rank%2==0){
	printf("Rank %d on %s\n",rank, name);
	double starttime, endtime;
	MPI_Status status;
	double dtime=0;
	for (int e=0;e<E;e++){
	starttime=MPI_Wtime();
	for (int i=0;i<128;i++){
		MPI_Send(&chunk,chunk_size,MPI_DOUBLE,rank+1,0,MPI_COMM_WORLD);
		MPI_Recv(chunk_recv,chunk_size,MPI_DOUBLE,MPI_ANY_SOURCE,MPI_ANY_TAG,MPI_COMM_WORLD,&status);	
	}
	endtime=MPI_Wtime();
	dtime+=endtime-starttime;
	}	
	double speed=B/(dtime/(2*E));
	printf("%d <--> %d Transmission Rate: %f MB/s\n",rank, rank+1,speed);
  }
  else{
    printf("Rank %d on %s\n",rank, name);
	MPI_Status status;
	for (int e=0;e<E;e++){
	for (int i=0;i<128;i++){
		MPI_Recv(chunk_recv,chunk_size,MPI_DOUBLE,MPI_ANY_SOURCE,MPI_ANY_TAG,MPI_COMM_WORLD,&status);	
		MPI_Send(&chunk_recv,chunk_size,MPI_DOUBLE,rank-1,0,MPI_COMM_WORLD);
	}
	}
  }
  MPI_Finalize();
}
