#include<stdio.h>
#include<stdlib.h>
#include<mpi.h>

int main(int argc, char** argv){
  MPI_Init(&argc,&argv);
  int total_procs;
  int rank;
  MPI_Comm_size(MPI_COMM_WORLD,&total_procs);
  MPI_Comm_rank(MPI_COMM_WORLD,&rank);
  if (rank==0){
    
    printf("Welcome to the message ring broadcaster.  Enter an integer to broadcast to all worker nodes.  Enter -1 to quit. \n");
    while(1){
    
    fflush(stdout);
    char input;
    scanf("%d",&input);
    int i;
    char* message=&input;
    MPI_Status status;
    MPI_Send(message,18,MPI_CHAR,1,0,MPI_COMM_WORLD);
    if(input==-1){break;}
    }
  }
  else{
    while(1){
    MPI_Status status;
    char recv_buffer[1];
    MPI_Recv(recv_buffer,20,MPI_CHAR,MPI_ANY_SOURCE,MPI_ANY_TAG,MPI_COMM_WORLD,&status);

    char received=*recv_buffer;
    char* message=&received;
    printf("Rank: %d Sender: %d Data:%d\n",rank,status.MPI_SOURCE,received);
	if(rank<total_procs-1){
	MPI_Send(message,18,MPI_CHAR,rank+1,0,MPI_COMM_WORLD);
	}    
	if(received==-1){break;}
    }
  }
  MPI_Finalize();
}
