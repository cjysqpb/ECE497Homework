#include<stdio.h>
#include<stdlib.h>
#include<mpi.h>
#include<time.h>
#include<math.h>

float Calculate_pi(long seed, long T){
	srand(seed);
	float rx,ry;
	long S=0;
	for (long j=0;j<T;j++){
		rx=(float)rand()/RAND_MAX;
		ry=(float)rand()/RAND_MAX;
		float diag=(float)hypot(rx,ry);
		if(diag<=1){S+=1;}
	}
	float pi=(float)((double)S/(double)T)*4;
	return pi;
}


int main(int argc, char** argv){
  MPI_Init(&argc,&argv);
  int total_procs;
  int rank;
  MPI_Comm_size(MPI_COMM_WORLD,&total_procs);
  MPI_Comm_rank(MPI_COMM_WORLD,&rank);
  long T=atol(argv[1]);
  if (rank==0){
    printf("Estimating PI using %li samples...\n", T);
	long seed=time(NULL);
    int i;
    MPI_Status status;
    for (i=1;i<total_procs;i++){
      MPI_Send(&seed,1,MPI_LONG,i,0,MPI_COMM_WORLD);
    }
	double starttime, endtime;
	starttime=MPI_Wtime();
	float pi_total=Calculate_pi(seed, T);
	for (i=1;i<total_procs;i++){
	  float pi_recv;
      MPI_Recv(&pi_recv,1,MPI_FLOAT,MPI_ANY_SOURCE,MPI_ANY_TAG,MPI_COMM_WORLD,&status);
	  pi_total+=pi_recv;
    }
	float pi=pi_total/(float)total_procs;
	endtime=MPI_Wtime();
	int dtime=(int)(endtime-starttime);
	printf("Using %li samples we got pi is approximately %f\n",T,pi);
	printf("Takes %d seconds\n", dtime);
  }
  else{

    MPI_Status status;
    long seed;
    MPI_Recv(&seed,1,MPI_LONG,MPI_ANY_SOURCE,MPI_ANY_TAG,MPI_COMM_WORLD,&status);
	seed+=rank;
	float pi=Calculate_pi(seed,T);
	MPI_Send(&pi,1,MPI_FLOAT,0,0,MPI_COMM_WORLD);

  }
  MPI_Finalize();
}
