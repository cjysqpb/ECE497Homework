#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define parallel
#include "nbodyutilstheta.h"
#include<mpi.h>

MPI_Datatype MPI_Vector;

///////////////////////////////////////////////////////////////////////Helper Methods////////////////////////////////////////////////////////////////

//Detect If number of processor is a cubic value.
int is_perfect_cube(int n) {
    double root=pow(n,(double)(1./3.));
    return n == root * root * root;
}

MPI_Datatype create_MPI_vector() {
	vector v;
	MPI_Datatype dtype[3] = { MPI_DOUBLE, MPI_DOUBLE, MPI_DOUBLE };
	int blocklen[3] = { 1, 1, 1 };
	MPI_Aint disp[3] = { (long int) &(v.x) - (long int) &v, (long int) &(v.y)
			- (long int) &v, (long int) &(v.z) - (long int) &v };
	MPI_Datatype vector_type;
	MPI_Type_create_struct(3, blocklen, disp, dtype, &vector_type);
	MPI_Type_commit(&vector_type);
	return vector_type;
}

//Calculate the gravitational force acting on body body_idx based on positions in x, 
//Use the mass and gravitational data available in d. 
//In particular, this will calcualte v'(t) for body body_idx and time t_idx. 
vector gravity_force_calc(int body_idx, vector* x, nbody_dataset* d,
		sim_opts* s) {
	vector F = zerovec();
	double test = s->theta;

	vector direction;
	//Loop over every section (every processor)
	for (int i = 0; i < s->numprocs; i++) {
		if (s->body_assmts_count[i] != 0) {
			double dist = vnorm(minus(x[body_idx], d->COM_coords[i]));
			//Large distance using centered mass
			if (dist > s->theta) {
				if (dist != 0) {direction = minus(d->COM_coords[i], x[body_idx]);
					F = plus(F,mult(direction,d->G * d->COM_mass[i]/ pow(vnorm(direction), 3)));
				}
			//Small distance using tradition precise calculation
			} else {
				for (int k = 0; k < s->body_assmts_count[i]; k++) {
					int index = s->body_assmts_data[i][k];
					if (index != body_idx) {
						direction = minus(x[index], x[body_idx]);
						F = plus(F,mult(direction,d->G * d->M[index]/ pow(vnorm(direction), 3)));
					}
				}
			}
		}
	}

	return F;

}

///////////////////////////////////////Main helper method///////////////////////////////////////////////////////
void evolve(sim_opts* s, nbody_dataset* d, MPI_Comm comm) {
	int rank;
	int nproc;

	MPI_Comm_size(comm, &nproc);
	MPI_Comm_rank(comm, &rank);
	MPI_Status status;
	//use fanciness here to convert d->X, which is indexed with one index, into
	//an array x that is indexed with two indices. Notice that writing to x
	//will update d->X.
	vector(*x)[d->N] = (vector (*)[d->N]) d->X;
	int i, j, N;
	N = d->N;

	//malloc room for velocity array
	//we don't actually care about storing the velocities, so this is just temporary
	vector* v = malloc(N * sizeof(vector));
	vector* vold = malloc(N * sizeof(vector));
	vector * dummy;

	//intermediate variables for improved Euler's method.  Allocate if needed.
	vector * xstar;
	vector * vstar;

	//intermediate variables for RK4. Allocate as needed;
	vector *K1X, *K2X, *K3X, *K4X;
	vector *K1V, *K2V, *K3V, *K4V;
	vector *S1X, *S2X, *S3X, *S4X;
	vector *S1V, *S2V, *S3V, *S4V;

	//copy initial conditions into x and v
	for (i = 0; i < d->N; i++) {
		x[0][i] = d->X0[i];
		vold[i] = d->V0[i];
	}

	//start time stepping
	int t;
	int k;

	vector M = zerovec();
	double t_mass;

	//set initial time
	d->times[0] = 0;
	double h = s->stepsize;
	switch (s->method) {
	case 1:
		fprintf(stderr, "Back to unsupported.\n");
		MPI_Abort(MPI_COMM_WORLD, 0);
		break;
	
	case 2:
		//Ok, use Euler's method to update every position in x and every velocity
		//Main loop.
		for (t = 1; t <= d->numsteps; t++) {

			//You only need to explictly update the bodies assigned to you in x.
			
			//Calculate Center of mass
			for (int i = 0; i < s->body_assmts_count[rank]; i++) {
				M.x = M.x+ d->M[s->body_assmts_data[rank][i]]* d->X0[s->body_assmts_data[rank][i]].x;
				M.y = M.y+ d->M[s->body_assmts_data[rank][i]]* d->X0[s->body_assmts_data[rank][i]].y;
				M.z = M.z+ d->M[s->body_assmts_data[rank][i]]* d->X0[s->body_assmts_data[rank][i]].z;
				t_mass = t_mass + d->M[s->body_assmts_data[rank][i]];
			}
			M.x = M.x / t_mass;
			M.y = M.y / t_mass;
			M.z = M.z / t_mass;
			if (s->body_assmts_count[rank] != 0) {
				t_mass = t_mass / s->body_assmts_count[rank];
			} else {
				//Nothing in the chunk
				t_mass = 0;
			}
			
			//Distribute COM
			d->COM_coords = malloc(nproc * sizeof(vector));
			d->COM_mass = malloc(nproc * sizeof(double));
			MPI_Allgather(&M, 1, MPI_Vector, d->COM_coords, 1, MPI_Vector,MPI_COMM_WORLD);
			MPI_Allgather(&t_mass, 1, MPI_DOUBLE, d->COM_mass, 1, MPI_DOUBLE,MPI_COMM_WORLD);
			
			//Updating, only loop through bodies supposed to be in this chunk.
			for (int k = 0; k < s->body_assmts_count[rank]; k++) {
				int index = s->body_assmts_data[rank][k];
				x[t][index] = plus(x[t - 1][index], mult(vold[index], h));
				//updating position is more involved, but same idea.
				v[index] = plus(vold[index],mult(gravity_force_calc(index, x[t - 1], d, s), h));
			}
			//Now all positions and velocities are updated, turn v into vold.  Then turn vold into v so that we can over-write it.
			dummy = v;
			v = vold;
			vold = dummy;
			
			//////////////////////////////////////////////////////////////Rank 0 Collect Data////////////////////////////////////////////////////////
			vector * X_temp;
			X_temp = malloc(N * sizeof(vector));
			if (rank == 0) {
				
				//Collect data from each processor. Place the data into X_temp to form a complete time step.
				//Collect data from itself
				for (int i = 0; i < s->body_assmts_count[0]; i++) {
					int index = s->body_assmts_data[0][i];
					X_temp[index] = x[t][index];
				}
				//Collect data from others
				for (int i = 1; i < nproc; i++) {
					vector * X_buffer;
					X_buffer = malloc(N * sizeof(vector));

					MPI_Recv(X_buffer, N, MPI_Vector, i, 10, comm, &status);
					
					//Collect and format data according to assigned index
					for (int j = 0; j < s->body_assmts_count[i]; j++) {
						int index = s->body_assmts_data[i][j];
						X_temp[index] = X_buffer[index];
					}
				}
			} else {
				//Not rank 0, just send sata.
				MPI_Send(x[t], N, MPI_Vector, 0, 10, comm);
			}
			
			///////////////////////////////////////////////////////////Rank 0 Redistribute Data//////////////////////////////////////////////////////////////

			if (rank == 0) {
				//Basically just re-do the initialization, without malloc.
				//Steps following in-class notes.
				
				//Step 1: coord min and max
				double coord_min_x, coord_max_x,coord_min_y, coord_max_y,coord_min_z, coord_max_z;
				coord_min_x = d->X0[0].x;
				coord_max_x = d->X0[0].x;
				coord_min_y = d->X0[0].y;
				coord_max_y = d->X0[0].y;
				coord_min_z = d->X0[0].z;
				coord_max_z = d->X0[0].z;
				for (int i = 1; i < N; i++) {
					if (d->X0[i].x < coord_min_x) {
						coord_min_x = d->X0[i].x;
					} else if (d->X0[i].x > coord_max_x) {
						coord_max_x = d->X0[i].x;
					}
					if (d->X0[i].y < coord_min_y) {
						coord_min_y = d->X0[i].y;
					} else if (d->X0[i].y > coord_max_y) {
						coord_max_y = d->X0[i].y;
					}
					if (d->X0[i].z < coord_min_z) {
						coord_min_z = d->X0[i].z;
					} else if (d->X0[i].z > coord_max_z) {
						coord_max_z = d->X0[i].z;
					}
				}
				
				//If number of processor is a cubic value then using cube division.
				int CubeDivide=is_perfect_cube(nproc);
				
				//Step 2: Assign chunk to each processor
				
				double partition_width_x,partition_width_y,partition_width_z;
				double temp=pow(nproc,(double)(1./3.));//The base of cube
				if (CubeDivide){
					partition_width_x = (coord_max_x - coord_min_x) / (temp);
					partition_width_y = (coord_max_y - coord_min_y) / (temp);
					partition_width_z = (coord_max_z - coord_min_z) / (temp);
				}else{
					partition_width_x = (coord_max_x - coord_min_x) / (s->numprocs);
					partition_width_y=0;
					partition_width_z=0;
				}

				s->partition_assmts = malloc(6 * s->numprocs * sizeof(double));
				
				temp=(int)temp;
				if (CubeDivide){
					for (int z = 0;z < temp; z++){
						for (int y= 0;y < temp; y++){
							for (int x = 0;x < temp;x++){
								int index=z*4+y*2+x;
								s->partition_assmts[index][0]=coord_min_x+partition_width_x*x;
								s->partition_assmts[index][1]=coord_min_x+partition_width_x*(x+1);
								s->partition_assmts[index][2]=coord_min_y+partition_width_y*y;
								s->partition_assmts[index][3]=coord_min_y+partition_width_y*(y+1);
								s->partition_assmts[index][4]=coord_min_z+partition_width_z*z;
								s->partition_assmts[index][5]=coord_min_z+partition_width_z*(z+1);
							}
						}
					}
				}else{
					//Linear dividde along x axis.
					s->partition_assmts[0][0] = coord_min_x;
					s->partition_assmts[0][1] = coord_min_x + partition_width_x;
					for (int i = 1; i < s->numprocs; i++) {
						s->partition_assmts[i][0] = s->partition_assmts[i - 1][1];
						s->partition_assmts[i][1] = s->partition_assmts[i][0]+ partition_width_x;
						if (i == s->numprocs - 1) {
							s->partition_assmts[i][1] = coord_max_x;
						}
					}
				}
				

				
				//Step 3: Distribute bodies into each chunk
				for (int i = 0; i < nproc; i++) {
					s->body_assmts_count[i] = 0;
				}
				for (int i = 0; i < N; i++) {
					double thisx = d->X0[i].x;
					double thisy = d->X0[i].y;
					double thisz = d->X0[i].z;
					for (int j = 0; j < s->numprocs; j++) {
						if (CubeDivide){
							if (thisx >= s->partition_assmts[j][0]&& thisx <= s->partition_assmts[j][1]&&
								thisy >= s->partition_assmts[j][2]&& thisy <= s->partition_assmts[j][3]&&
								thisz >= s->partition_assmts[j][4]&& thisz <= s->partition_assmts[j][5]) {
								s->body_assmts_data[j][s->body_assmts_count[j]] = i;
								s->body_assmts_count[j] = s->body_assmts_count[j] + 1;
								break;
							}
						}else{
							if (thisx >= s->partition_assmts[j][0]&& thisx <= s->partition_assmts[j][1]) {
								s->body_assmts_data[j][s->body_assmts_count[j]] = i;
								s->body_assmts_count[j] = s->body_assmts_count[j] + 1;
								break;
							}
						}
					}
				}
			

				//Rank 0 broadcasts data
				MPI_Bcast(s->partition_assmts, 6 * s->numprocs, MPI_DOUBLE, 0,MPI_COMM_WORLD);
				MPI_Bcast(s->body_assmts_data, 999 * s->numprocs, MPI_INT, 0,MPI_COMM_WORLD);
				MPI_Bcast(s->body_assmts_count, s->numprocs, MPI_INT, 0,MPI_COMM_WORLD);
				MPI_Bcast(X_temp, N, MPI_Vector, 0, MPI_COMM_WORLD);

			} else {
				//Not Rank 0 receive data.
				MPI_Bcast(s->partition_assmts, 6 * s->numprocs, MPI_DOUBLE, 0,MPI_COMM_WORLD);
				MPI_Bcast(s->body_assmts_data, 999 * s->numprocs, MPI_INT, 0,MPI_COMM_WORLD);
				MPI_Bcast(s->body_assmts_count, s->numprocs, MPI_INT, 0,MPI_COMM_WORLD);
				MPI_Bcast(X_temp, N, MPI_Vector, 0, MPI_COMM_WORLD);
			}
			
			//Copy into x[t]. STUPID Slow but error-free.
			for (int i = 0; i < N; i++) {
				x[t][i] = X_temp[i];
			}
			
			//Do not know how to Allgatherv when index of bodies is changing.
			//MPI_Allgatherv(MPI_IN_PLACE,0,MPI_INT,x[t],s->body_count,s->global_displs,MPI_Vector,MPI_COMM_WORLD);
		}
		break;
		
	case 3:

		fprintf(stderr, "Yeah, not supported again.\n");
		MPI_Abort(MPI_COMM_WORLD, 0);
		break;
	}

	free(vold);
	free(v);
}

///////////////////////////////////////////////////////////////////////////MAIN///////////////////////////////////////////////////////////////
void main(int argc, char** argv) {

	MPI_Init(&argc, &argv);
	MPI_Vector = create_MPI_vector();
	int rank;
	int nproc;

	MPI_Comm_size(MPI_COMM_WORLD, &nproc);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);

	nbody_dataset d;
	sim_opts s;

	//rank 0 should:
	//a) read the simulation options
	//b) read in the dataset
	//c) decide which processors are doing what jobs
	//d) distribute the options and dataset
	if (rank == 0) {
		//a)
		read_sim_opts(argc, argv, &s);
		print_options(s);
		if (argc < 3) {
			print_usage();
			MPI_Abort(MPI_COMM_WORLD, 0);
		}

		//b)
		load_data(argv[1], &d);
		
		//If number of processor is a cubic value then using cube division.
		int CubeDivide=is_perfect_cube(nproc);
		if (CubeDivide){
			printf("Using Cubic 3D Dividing\n");
		}else{
			printf("Using linear dividing along x axis\n");
		}
		
		//Steps following in-class notes.
		
		//////////////////////////////////////////////////////////Initialize/////////////////////////
		//Step1: Min and Max
		int N;
		N = d.N;
		double coord_min_x, coord_max_x,coord_min_y, coord_max_y,coord_min_z, coord_max_z;
		coord_min_x = d.X0[0].x;
		coord_max_x = d.X0[0].x;
		coord_min_y = d.X0[0].y;
		coord_max_y = d.X0[0].y;
		coord_min_z = d.X0[0].z;
		coord_max_z = d.X0[0].z;
		for (int i = 1; i < N; i++) {
			if (d.X0[i].x < coord_min_x) {
				coord_min_x = d.X0[i].x;
			} else if (d.X0[i].x > coord_max_x) {
				coord_max_x = d.X0[i].x;
			}
			if (d.X0[i].y < coord_min_y) {
				coord_min_y = d.X0[i].y;
			} else if (d.X0[i].y > coord_max_y) {
				coord_max_y = d.X0[i].y;
			}
			if (d.X0[i].z < coord_min_z) {
				coord_min_z = d.X0[i].z;
			} else if (d.X0[i].z > coord_max_z) {
				coord_max_z = d.X0[i].z;
			}
		}

		//Step2: Assign chunk to each processor
		double partition_width_x,partition_width_y,partition_width_z;
		double temp=pow(nproc,(double)(1./3.));//The base of cube.
		if (CubeDivide){
			partition_width_x = (coord_max_x - coord_min_x) / (temp);
			partition_width_y = (coord_max_y - coord_min_y) / (temp);
			partition_width_z = (coord_max_z - coord_min_z) / (temp);
		}else{
			partition_width_x = (coord_max_x - coord_min_x) / (s.numprocs);
			partition_width_y=0;
			partition_width_z=0;
		}
		
		s.partition_assmts = malloc(6 * s.numprocs * sizeof(double));
		
		temp=(int)temp;
		if (CubeDivide){
			for (int z = 0;z < temp; z++){
				for (int y= 0;y < temp; y++){
					for (int x = 0;x < temp;x++){
						int index=z*4+y*2+x;
						s.partition_assmts[index][0]=coord_min_x+partition_width_x*x;
						s.partition_assmts[index][1]=coord_min_x+partition_width_x*(x+1);
						s.partition_assmts[index][2]=coord_min_y+partition_width_y*y;
						s.partition_assmts[index][3]=coord_min_y+partition_width_y*(y+1);
						s.partition_assmts[index][4]=coord_min_z+partition_width_z*z;
						s.partition_assmts[index][5]=coord_min_z+partition_width_z*(z+1);
					}
				}
			}
		}else{
			//Linear divide along x axis.
			s.partition_assmts[0][0] = coord_min_x;
			s.partition_assmts[0][1] = coord_min_x + partition_width_x;
			for (int i = 1; i < s.numprocs; i++) {
				s.partition_assmts[i][0] = s.partition_assmts[i - 1][1];
				s.partition_assmts[i][1] = s.partition_assmts[i][0]+ partition_width_x;
				if (i == s.numprocs - 1) {
					s.partition_assmts[i][1] = coord_max_x;
				}
			}
		}

		//Step 3: Distribute bodies into each chunk
		//Assume 999 is big enough for single chunk.
		s.body_assmts_data = malloc(999 * s.numprocs * sizeof(int));
		s.body_assmts_count = malloc(s.numprocs * sizeof(int));
		for (int i = 0; i < s.numprocs; i++) {
			s.body_assmts_count[i] = 0;
		}
		for (int i = 0; i < N; i++) {
			double thisx = d.X0[i].x;
			double thisy = d.X0[i].y;
			double thisz = d.X0[i].z;
			for (int j = 0; j < s.numprocs; j++) {
				if (CubeDivide){
					if (thisx >= s.partition_assmts[j][0]&& thisx <= s.partition_assmts[j][1]&&
						thisy >= s.partition_assmts[j][2]&& thisy <= s.partition_assmts[j][3]&&
						thisz >= s.partition_assmts[j][4]&& thisz <= s.partition_assmts[j][5]) {
						s.body_assmts_data[j][s.body_assmts_count[j]] = i;
						s.body_assmts_count[j] = s.body_assmts_count[j] + 1;
						break;
					}
				}else{
					if (thisx >= s.partition_assmts[j][0]&& thisx <= s.partition_assmts[j][1]) {
						s.body_assmts_data[j][s.body_assmts_count[j]] = i;
						s.body_assmts_count[j] = s.body_assmts_count[j] + 1;
						break;
					}
				}
			}
		}
		
		
		//Calculate theta
		double rij=partition_width_x/s.theta;
		s.theta=rij;

		
		//d): Distribute Data
		MPI_Bcast(&s.numsteps, 1, MPI_INT, 0, MPI_COMM_WORLD);
		MPI_Bcast(&s.endtime, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
		MPI_Bcast(&s.stepsize, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
		MPI_Bcast(&s.numprocs, 1, MPI_INT, 0, MPI_COMM_WORLD);
		MPI_Bcast(&s.method, 1, MPI_INT, 0, MPI_COMM_WORLD);

		MPI_Bcast(s.partition_assmts, 6 * s.numprocs, MPI_DOUBLE, 0,MPI_COMM_WORLD);
		MPI_Bcast(s.body_assmts_data, 999 * s.numprocs, MPI_INT, 0,MPI_COMM_WORLD);
		MPI_Bcast(s.body_assmts_count, s.numprocs, MPI_INT, 0, MPI_COMM_WORLD);
		MPI_Bcast(&s.theta, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);

		MPI_Bcast(&d.N, 1, MPI_INT, 0, MPI_COMM_WORLD);
		MPI_Bcast(&d.G, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
		MPI_Bcast(d.X0, d.N, MPI_Vector, 0, MPI_COMM_WORLD);
		MPI_Bcast(d.V0, d.N, MPI_Vector, 0, MPI_COMM_WORLD);
		MPI_Bcast(d.M, d.N, MPI_DOUBLE, 0, MPI_COMM_WORLD);
		MPI_Bcast(&d.numsteps, 1, MPI_INT, 0, MPI_COMM_WORLD);

	}

	else {
		//The workers just get the info from the master and feed it into their data structures.
		MPI_Bcast(&s.numsteps, 1, MPI_INT, 0, MPI_COMM_WORLD);
		MPI_Bcast(&s.endtime, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
		MPI_Bcast(&s.stepsize, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
		MPI_Bcast(&s.numprocs, 1, MPI_INT, 0, MPI_COMM_WORLD);
		MPI_Bcast(&s.method, 1, MPI_INT, 0, MPI_COMM_WORLD);
		s.rank = rank;

		s.body_assmts_data = malloc(999 * s.numprocs * sizeof(int));
		s.body_assmts_count = malloc(s.numprocs * sizeof(int));
		s.partition_assmts = malloc(6 * s.numprocs * sizeof(double));
		MPI_Bcast(s.partition_assmts, 6 * s.numprocs, MPI_DOUBLE, 0,MPI_COMM_WORLD);
		MPI_Bcast(s.body_assmts_data, 999 * s.numprocs, MPI_INT, 0,MPI_COMM_WORLD);
		MPI_Bcast(s.body_assmts_count, s.numprocs, MPI_INT, 0, MPI_COMM_WORLD);
		MPI_Bcast(&s.theta, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);

		MPI_Bcast(&d.N, 1, MPI_INT, 0, MPI_COMM_WORLD);
		MPI_Bcast(&d.G, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
		d.X0 = malloc(sizeof(vector) * d.N * (s.numsteps + 1));
		d.V0 = malloc(sizeof(vector) * d.N * (s.numsteps + 1));
		MPI_Bcast(d.X0, d.N, MPI_Vector, 0, MPI_COMM_WORLD);
		MPI_Bcast(d.V0, d.N, MPI_Vector, 0, MPI_COMM_WORLD);
		d.M = malloc(d.N * sizeof(double));
		MPI_Bcast(d.M, d.N, MPI_DOUBLE, 0, MPI_COMM_WORLD);
		MPI_Bcast(&d.numsteps, 1, MPI_INT, 0, MPI_COMM_WORLD);

	}
	if (rank == 0) {
		fprintf(stdout, "Read %d records.\n", d.N);
		printf("\n");
	}
	
	//Print distribution data
/* 	printf("Processor %d has min %f and max %f \n", rank,
			s.partition_assmts[rank][0], s.partition_assmts[rank][1]);
	printf("Processor %d has index: ", rank);
	for (int i = 0; i < s.body_assmts_count[rank]; i++) {
		printf("%d ", s.body_assmts_data[rank][i]);
	}
	printf("End \n");
	printf("\n"); */

	d.X = malloc(d.N * (s.numsteps + 1) * sizeof(vector));
	d.times = malloc((s.numsteps + 1) * sizeof(double));
	d.numsteps = s.numsteps;
	
	double start,end;
	if (rank == 0) {
		printf("\n");
		fprintf(stdout, "Starting simulation.\n");
		start =MPI_Wtime();
	}
	evolve(&s, &d, MPI_COMM_WORLD);

	if (rank == 0) {
		end=MPI_Wtime();
		fprintf(stdout, "Finished simulation\n");
		fprintf(stdout, "Writing data to %s\n", argv[2]);
		write_data(argv[2], &d);
		printf("Simulation takes %f seconds to run.\n",end-start);
	}
	
	
	
	free(d.X);
	free(d.times);
	free(d.X0);
	free(d.V0);
	free(d.M);
	fprintf(stdout, "Done.\n");
	MPI_Finalize();
}
