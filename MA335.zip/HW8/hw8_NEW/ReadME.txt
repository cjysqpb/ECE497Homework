Code is based on nbody_parallel_stripped_2.c. The code works correctly, excpet one case that "end=1y step=1m" may generate error.
If the #np is perfect cubic, the program will do cubic dividing. If not, it will divide the task along the x axis. 
dij=distance/theta: distance is the x-axis step distance.

Processing time is calculated and shown to have fun.

threshold: theta=1000 nearly explodes the solar system.

Some parts of this coding was a pair-programming with Boyu Zhang: working together has much better efficiency. 
