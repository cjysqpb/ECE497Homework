#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define parallel
#include "nbodyutils.h"
#include<mpi.h>

MPI_Datatype MPI_Vector;

MPI_Datatype create_MPI_vector(){
  vector v;
  MPI_Datatype dtype[3]={MPI_DOUBLE,MPI_DOUBLE,MPI_DOUBLE};
  int blocklen[3]={1,1,1};
  MPI_Aint disp[3]={(long int)&(v.x)-(long int)&v,(long int)&(v.y)-(long int)&v,(long int)&(v.z)-(long int)&v};
  MPI_Datatype vector_type;
  MPI_Type_create_struct(3, blocklen, disp, dtype, &vector_type);
  MPI_Type_commit(&vector_type);
  return vector_type;
}

//Calculate the gravitational force acting on body body_idx based on positions in x, 
//Use the mass and gravitational data available in d. 
//In particular, this will calcualte v'(t) for body body_idx and time t_idx. 
vector gravity_force_calc(int body_idx, vector* x,nbody_dataset* d){
  vector F=zerovec();
  int k;
  vector direction;
  for (k=0;k<d->N;k++){
    if (k!= body_idx){
      direction=minus(x[k],x[body_idx]);
      F=plus(F,mult(direction,d->G*d->M[k]/pow(vnorm(direction),3)));
    }
  }
  //  F=mult(F,d->G);
  return F;

}

void evolve(sim_opts* s, nbody_dataset* d){

  //use fanciness here to convert d->X, which is indexed with one index, into 
  //an array x that is indexed with two indices. Notice that writing to x 
  //will update d->X.
  vector (*x)[d->N] = (vector (*)[d->N])d->X;
  int i,j,N;
  N=d->N;

  //malloc room for velocity array
  //we don't actually care about storing the velocities, so this is just temporary
  vector* v=malloc(N*sizeof(vector));
  vector* vold=malloc(N*sizeof(vector));
  vector* dummy;

  //intermediate variables for improved Euler's method.  Allocate if needed.
  vector* xstar;
  vector* vstar;

  //intermediate variables for RK4. Allocate as needed;
  vector *K1X,*K2X,*K3X,*K4X;
  vector *K1V,*K2V,*K3V,*K4V;
  vector *S1X,*S2X,*S3X,*S4X;
  vector *S1V,*S2V,*S3V,*S4V;
  
  //copy initial conditions into x and v
  for (i=0;i<d->N;i++){
    x[0][i]=d->X0[i];
    vold[i]=d->V0[i];
  }

  
  //start time stepping
  int t;
  int k;
  //set initial time
  d->times[0]=0;
  double h=s->stepsize;
  switch (s->method){
  case 1:
    fprintf(stderr,"Back to unsupported.\n");
    MPI_Abort(MPI_COMM_WORLD,0);
    K1X=malloc(N*sizeof(vector)); K2X=malloc(N*sizeof(vector)); K3X=malloc(N*sizeof(vector)); K4X=malloc(N*sizeof(vector));
    K1V=malloc(N*sizeof(vector)); K2V=malloc(N*sizeof(vector)); K3V=malloc(N*sizeof(vector)); K4V=malloc(N*sizeof(vector));
    S1X=malloc(N*sizeof(vector)); S2X=malloc(N*sizeof(vector)); S3X=malloc(N*sizeof(vector)); S4X=malloc(N*sizeof(vector));
    S1V=malloc(N*sizeof(vector)); S2V=malloc(N*sizeof(vector)); S3V=malloc(N*sizeof(vector)); S4V=malloc(N*sizeof(vector));

    for (t=1;t<=d->numsteps;t++){
      //Ok, calculate K1 for position and velocity.
      //Now STAGE 1 is calculable. 
      for (i=0;i<N;i++){
	K1X[i]=vold[i];
	S1X[i]=plus(x[t-1][i], mult(K1X[i],h/2));
	K1V[i]=gravity_force_calc(i,x[t-1],d);
	S1V[i]=plus(vold[i],mult(K1V[i],h/2));
      }

      //And now K2, followed by Stage 2
      for(i=0;i<N;i++){
	K2X[i]=S1V[i];
	S2X[i]=plus(x[t-1][i],mult(K2X[i],h/2));
	K2V[i]=gravity_force_calc(i,S1X,d);
	S2V[i]=plus(vold[i],mult(K2V[i],h/2));
      }

      //And now K3, followed by Stage 3
      for(i=0;i<N;i++){
	K3X[i]=S2V[i];
	S3X[i]=plus(x[t-1][i],mult(K3X[i],h));
	K3V[i]=gravity_force_calc(i,S2X,d);
	S3V[i]=plus(vold[i],mult(K3V[i],h));
      }
      //And now K4, there is no need for Stage 4
      for(i=0;i<N;i++){
	K4X[i]=S3V[i];
	K4V[i]=gravity_force_calc(i,S3X,d);
      }
      //And now finally combind the K's
      for (i=0;i<N;i++){
	x[t][i]=plus(x[t-1][i],mult(plus(plus(plus(K1X[i],mult(K2X[i],2)),mult(K3X[i],2)),K4X[i]),h/6));
	v[i]=plus(vold[i],mult(plus(plus(plus(K1V[i],mult(K2V[i],2)),mult(K3V[i],2)),K4V[i]),h/6));
      }
//Now all positions and velocities are updated, turn v into vold.  Then turn vold into v so that we can over-write it.    
      dummy=v;
      v=vold;
      vold=dummy;      
    }
    free(K1X);free(K2X);free(K3X);free(K4X);
    free(S1X);free(S2X);free(S3X);free(S4X);
    free(K1V);free(K2V);free(K3V);free(K4V);
    free(S1V);free(S2V);free(S3V);free(S4V);
    
    break;
  case 2:
    //Ok, use Euler's method to update every position in x and every velocity 
    for (t=1;t<= d->numsteps; t++){

      //You only need to explictly update the bodies assigned to you in x.
      
      for (i=s->body_assmts[s->rank][0];i<=s->body_assmts[s->rank][1];i++){
	x[t][i]=plus(x[t-1][i],mult(vold[i],h));
	//updating position is more involved, but same idea.
	v[i]=plus(vold[i], mult(gravity_force_calc(i,x[t-1],d),h));
      }
      //Now all positions and velocities are updated, turn v into vold.  Then turn vold into v so that we can over-write it.    
      dummy=v;
      v=vold;
      vold=dummy;

    }
    break;
  case 3:

    fprintf(stderr,"Yeah, not supported again.\n");
    MPI_Abort(MPI_COMM_WORLD,0);
    //Ok, use Improved Euler's method to update every position in x and every velocity 
    xstar=malloc(N*sizeof(vector));
    vstar=malloc(N*sizeof(vector));
    
    for (t=1;t<= d->numsteps; t++){
      //update using Euler's method into the temporary variables. 
      for (i=0;i<d->N;i++){
	xstar[i]=plus(x[t-1][i],mult(vold[i],h));
	vstar[i]=plus(vold[i], mult(gravity_force_calc(i,x[t-1],d),h));
      }
      //Now use improved Euler's method to update again.
      for (i=0;i<d->N;i++){
	x[t][i]=plus(x[t-1][i],mult(plus(vold[i],vstar[i]),h/2));
	v[i]=plus(vold[i],mult(plus(gravity_force_calc(i,x[t-1],d),gravity_force_calc(i,xstar,d)),h/2));
      }
      dummy=v;
      v=vold;
      vold=dummy;
    }
    free(xstar); free(vstar);
    break;    
  }
   
  free(vold); 
  free(v);
}



void main(int argc,char** argv){

  MPI_Init(&argc,&argv);
  MPI_Vector = create_MPI_vector();
  int rank;
  int nproc;
  
  MPI_Comm_size(MPI_COMM_WORLD,&nproc);
  MPI_Comm_rank(MPI_COMM_WORLD,&rank);
  
  nbody_dataset d;
  sim_opts s;

  //rank 0 should:
  //a) read the simulation options
  //b) read in the dataset
  //c) decide which processors are doing what jobs
  //d) distribute the options and dataset
  if (rank==0){
    //a)
    read_sim_opts(argc,argv,&s);
    print_options(s);
    if (argc<3){
      print_usage();
      MPI_Abort(MPI_COMM_WORLD,0);
    }

    //b)
    load_data(argv[1],&d);

    //c)
    int i;
    s.body_assmts=malloc(2*s.numprocs*sizeof(int));
    s.body_count=malloc(s.numprocs*sizeof(int));
    s.global_displs=malloc(s.numprocs*sizeof(int));
    
    s.body_assmts[0][0]=0;
    s.global_displs[0]=0;
    s.body_assmts[0][1]=d.N/s.numprocs-1;
    for (i=1;i<s.numprocs;i++){
      s.body_assmts[i][0]=s.body_assmts[i-1][1]+1;
      s.global_displs[i]=s.body_assmts[i][0];
      s.body_assmts[i][1]=s.body_assmts[i][0] + d.N/s.numprocs-1;
      if (i==s.numprocs -1){
	s.body_assmts[i][1]=d.N-1;
      }
    }
    for (i=0;i<s.numprocs;i++){
      s.body_count[i]=s.body_assmts[i][1]-s.body_assmts[i][0]+1;
    }

    //d)
    MPI_Bcast(&s.numsteps,1,MPI_INT,0,MPI_COMM_WORLD);
    MPI_Bcast(&s.endtime,1,MPI_DOUBLE,0,MPI_COMM_WORLD);
    MPI_Bcast(&s.stepsize,1,MPI_DOUBLE,0,MPI_COMM_WORLD);
    MPI_Bcast(&s.numprocs,1,MPI_INT,0,MPI_COMM_WORLD);
    MPI_Bcast(s.body_assmts,2*s.numprocs,MPI_INT,0,MPI_COMM_WORLD);
    MPI_Bcast(s.global_displs,s.numprocs,MPI_INT,0,MPI_COMM_WORLD);
    MPI_Bcast(s.body_count,s.numprocs,MPI_INT,0,MPI_COMM_WORLD);
    MPI_Bcast(&s.method,1,MPI_INT,0,MPI_COMM_WORLD);

    MPI_Bcast(&d.N,1,MPI_INT,0,MPI_COMM_WORLD);
    MPI_Bcast(&d.G,1,MPI_DOUBLE,0,MPI_COMM_WORLD);
    MPI_Bcast(d.X0,d.N,MPI_Vector,0,MPI_COMM_WORLD);
    MPI_Bcast(d.V0,d.N,MPI_Vector,0,MPI_COMM_WORLD);
    MPI_Bcast(d.M,d.N,MPI_DOUBLE,0,MPI_COMM_WORLD);
    MPI_Bcast(&d.numsteps,1,MPI_INT,0,MPI_COMM_WORLD);

  }

  else{
    //The workers just get the info from the master and feed it into their data structures.
    MPI_Bcast(&s.numsteps,1,MPI_INT,0,MPI_COMM_WORLD);
    MPI_Bcast(&s.endtime,1,MPI_DOUBLE,0,MPI_COMM_WORLD);
    MPI_Bcast(&s.stepsize,1,MPI_DOUBLE,0,MPI_COMM_WORLD);
    MPI_Bcast(&s.numprocs,1,MPI_INT,0,MPI_COMM_WORLD);
    s.body_assmts=malloc(2*s.numprocs*sizeof(int));
    MPI_Bcast(s.body_assmts,2*s.numprocs,MPI_INT,0,MPI_COMM_WORLD);
    s.global_displs=malloc(s.numprocs*sizeof(int));
    MPI_Bcast(s.global_displs,s.numprocs,MPI_INT,0,MPI_COMM_WORLD);
    s.body_count=malloc(s.numprocs*sizeof(int));
    MPI_Bcast(s.body_count,s.numprocs,MPI_INT,0,MPI_COMM_WORLD);
    MPI_Bcast(&s.method,1,MPI_INT,0,MPI_COMM_WORLD);
    s.rank=rank;
    
    MPI_Bcast(&d.N,1,MPI_INT,0,MPI_COMM_WORLD);
    MPI_Bcast(&d.G,1,MPI_DOUBLE,0,MPI_COMM_WORLD);
    d.X0=malloc(sizeof(vector)*d.N*(s.numsteps+1));
    d.V0=malloc(sizeof(vector)*d.N*(s.numsteps+1));
    MPI_Bcast(d.X0,d.N,MPI_Vector,0,MPI_COMM_WORLD);
    MPI_Bcast(d.V0,d.N,MPI_Vector,0,MPI_COMM_WORLD);
    d.M=malloc(d.N*sizeof(double));
    MPI_Bcast(d.M,d.N,MPI_DOUBLE,0,MPI_COMM_WORLD);
    MPI_Bcast(&d.numsteps,1,MPI_INT,0,MPI_COMM_WORLD);

  }
  if (rank==0){  
    fprintf(stdout,"Read %d records.\n",d.N);
  }
  int i;
  
  d.X=malloc(d.N*(s.numsteps+1)*sizeof(vector));
  d.times=malloc((s.numsteps+1)*sizeof(double));
  d.numsteps=s.numsteps;

    
  if (rank==0){
    fprintf(stdout,"Starting simulation.\n");
  }
  
  evolve(&s,&d);

  if (rank==0){
    fprintf(stdout,"Finished simulation\n");
    fprintf(stdout,"Writing data to %s\n",argv[2]);
    write_data(argv[2],&d);
  }
  
  free(d.X);
  free(d.times);
  free(d.X0);
  free(d.V0);
  free(d.M);
  fprintf(stdout,"Done.\n");
  MPI_Finalize();
}
