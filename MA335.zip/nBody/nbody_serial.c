#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define serial
#include "nbodyutils.h"


//Calculate the gravitational force acting on body body_idx at time time_idx, 
//assuming that all the data in d for time time_idx-1 is up to date. 
//In particular, this will calcualte v'(t) for body body_idx and time t_idx. 
vector gravity_force_calc(int body_idx, vector* x,nbody_dataset* d){
  vector F=zerovec();
  int k;
  vector direction;
  for (k=0;k<d->N;k++){
    if (k!= body_idx){
      direction=minus(x[k],x[body_idx]);
      F=plus(F,mult(direction,d->G*d->M[k]/pow(vnorm(direction),3)));
    }
  }
  //  F=mult(F,d->G);
  return F;

}

void evolve(sim_opts* s, nbody_dataset* d){

  //use fanciness here to convert d->X, which is indexed with one index, into 
  //an array x that is indexed with two indices. Notice that writing to x 
  //will update d->X.
  vector (*x)[d->N] = (vector (*)[d->N])d->X;
  int i,j,N;
  N=d->N;

  //malloc room for velocity array
  //we don't actually care about storing the velocities, so this is just temporary
  vector* v=malloc(N*sizeof(vector));
  vector* vold=malloc(N*sizeof(vector));
  vector* dummy;

  //intermediate variables for improved Euler's method.  Allocate if needed.
  vector* xstar;
  vector* vstar;

  //intermediate variables for RK4. Allocate as needed;
  vector *K1X,*K2X,*K3X,*K4X;
  vector *K1V,*K2V,*K3V,*K4V;
  vector *S1X,*S2X,*S3X,*S4X;
  vector *S1V,*S2V,*S3V,*S4V;
  
  //copy initial conditions into x and v
  for (i=0;i<d->N;i++){
    x[0][i]=d->X0[i];
    vold[i]=d->V0[i];
  }

  
  //start time stepping
  int t;
  int k;
  //set initial time
  d->times[0]=0;
  double h=s->stepsize;
  switch (s->method){
  case 1:
    K1X=malloc(N*sizeof(vector)); K2X=malloc(N*sizeof(vector)); K3X=malloc(N*sizeof(vector)); K4X=malloc(N*sizeof(vector));
    K1V=malloc(N*sizeof(vector)); K2V=malloc(N*sizeof(vector)); K3V=malloc(N*sizeof(vector)); K4V=malloc(N*sizeof(vector));
    S1X=malloc(N*sizeof(vector)); S2X=malloc(N*sizeof(vector)); S3X=malloc(N*sizeof(vector)); S4X=malloc(N*sizeof(vector));
    S1V=malloc(N*sizeof(vector)); S2V=malloc(N*sizeof(vector)); S3V=malloc(N*sizeof(vector)); S4V=malloc(N*sizeof(vector));

    for (t=1;t<=d->numsteps;t++){
      //Ok, calculate K1 for position and velocity.
      //Now STAGE 1 is calculable. 
      for (i=0;i<N;i++){
	K1X[i]=vold[i];
	S1X[i]=plus(x[t-1][i], mult(K1X[i],h/2));
	K1V[i]=gravity_force_calc(i,x[t-1],d);
	S1V[i]=plus(vold[i],mult(K1V[i],h/2));
      }

      //And now K2, followed by Stage 2
      for(i=0;i<N;i++){
	K2X[i]=S1V[i];
	S2X[i]=plus(x[t-1][i],mult(K2X[i],h/2));
	K2V[i]=gravity_force_calc(i,S1X,d);
	S2V[i]=plus(vold[i],mult(K2V[i],h/2));
      }

      //And now K3, followed by Stage 3
      for(i=0;i<N;i++){
	K3X[i]=S2V[i];
	S3X[i]=plus(x[t-1][i],mult(K3X[i],h));
	K3V[i]=gravity_force_calc(i,S2X,d);
	S3V[i]=plus(vold[i],mult(K3V[i],h));
      }
      //And now K4, there is no need for Stage 4
      for(i=0;i<N;i++){
	K4X[i]=S3V[i];
	K4V[i]=gravity_force_calc(i,S3X,d);
      }
      //And now finally combind the K's
      for (i=0;i<N;i++){
	x[t][i]=plus(x[t-1][i],mult(plus(plus(plus(K1X[i],mult(K2X[i],2)),mult(K3X[i],2)),K4X[i]),h/6));
	v[i]=plus(vold[i],mult(plus(plus(plus(K1V[i],mult(K2V[i],2)),mult(K3V[i],2)),K4V[i]),h/6));
      }
//Now all positions and velocities are updated, turn v into vold.  Then turn vold into v so that we can over-write it.    
      dummy=v;
      v=vold;
      vold=dummy;      
    }
    free(K1X);free(K2X);free(K3X);free(K4X);
    free(S1X);free(S2X);free(S3X);free(S4X);
    free(K1V);free(K2V);free(K3V);free(K4V);
    free(S1V);free(S2V);free(S3V);free(S4V);
    
    break;
  case 2:
    //Ok, use Euler's method to update every position in x and every velocity 
    for (t=1;t<= d->numsteps; t++){
      for (i=0;i<d->N;i++){
	x[t][i]=plus(x[t-1][i],mult(vold[i],h));
	//updating position is more involved, but same idea.
	v[i]=plus(vold[i], mult(gravity_force_calc(i,x[t-1],d),h));
      }
      //Now all positions and velocities are updated, turn v into vold.  Then turn vold into v so that we can over-write it.    
      dummy=v;
      v=vold;
      vold=dummy;
    }
    break;
  case 3:
    //Ok, use Improved Euler's method to update every position in x and every velocity 
    xstar=malloc(N*sizeof(vector));
    vstar=malloc(N*sizeof(vector));
    
    for (t=1;t<= d->numsteps; t++){
      //update using Euler's method into the temporary variables. 
      for (i=0;i<d->N;i++){
	xstar[i]=plus(x[t-1][i],mult(vold[i],h));
	vstar[i]=plus(vold[i], mult(gravity_force_calc(i,x[t-1],d),h));
      }
      //Now use improved Euler's method to update again.
      for (i=0;i<d->N;i++){
	x[t][i]=plus(x[t-1][i],mult(plus(vold[i],vstar[i]),h/2));
	v[i]=plus(vold[i],mult(plus(gravity_force_calc(i,x[t-1],d),gravity_force_calc(i,xstar,d)),h/2));
      }
      dummy=v;
      v=vold;
      vold=dummy;
    }
    free(xstar); free(vstar);
    break;    
  }
   
  free(vold); 
  free(v);
}



void main(int argc,char** argv){

  nbody_dataset d;
  sim_opts s;


  read_sim_opts(argc,argv,&s);
  print_options(s);
  if (argc<3){

    print_usage();
    exit(1);
  }
  
  load_data(argv[1],&d);

  d.X=malloc(d.N*(s.numsteps+1)*sizeof(vector));
  d.times=malloc((s.numsteps+1)*sizeof(double));
  d.numsteps=s.numsteps;

  fprintf(stdout,"Read %d records.\n",d.N);
  fprintf(stdout,"Starting simulation.\n");

  double start=MPI_Wtime();
  evolve(&s,&d);
  double end=MPI_Wtime();
  
  fprintf(stdout,"Finished simulation\n");
  fprintf(stdout,"Elapsed time: %f\n",end-start);
  fprintf(stdout,"Writing data to %s\n",argv[2]);
  write_data(argv[2],&d);
  free(d.X);
  free(d.times);
  free(d.X0);
  free(d.V0);
  free(d.M);
  fprintf(stdout,"Done.\n");

}
